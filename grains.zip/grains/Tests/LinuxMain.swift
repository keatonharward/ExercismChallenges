import XCTest
@testable import GrainsTests

XCTMain([
    testCase(GrainsTests.allTests),
    ])
